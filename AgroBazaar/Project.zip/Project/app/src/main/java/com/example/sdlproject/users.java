package com.example.sdlproject;

public class users {
    public String name, type;

    public users(String name, String type) {
        this.name = name;
        this.type = type;
    }
}
